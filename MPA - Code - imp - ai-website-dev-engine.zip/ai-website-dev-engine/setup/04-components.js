const fs=require("fs")
const path=require("path")

const project=process.argv[2]
process.chdir(project)

function write(file,content){

 const dir=path.dirname(file)

 if(!fs.existsSync(dir)){
  fs.mkdirSync(dir,{recursive:true})
 }

 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }

}

/* SVG logo name */

write("src/assets/logo.svg",`
<svg
 xmlns="http://www.w3.org/2000/svg"
 viewBox="0 0 100 100"
 width="40"
 height="40"
 class="logo-svg"
>

 <circle
  cx="50"
  cy="50"
  r="45"
  stroke="#6366f1"
  stroke-width="6"
  fill="none"
 />

 <text
  x="50%"
  y="55%"
  text-anchor="middle"
  font-size="50"
  fill="#63f1bf"
  font-family="Arial"
  dy=".3em"
 >
  P
 </text>

</svg>
`)

/* NAVBAR */

write("src/components/Navbar/Navbar.tsx",`
import {useState,useEffect,useRef} from "react"
import {Link} from "react-router-dom"
import logo from "../../assets/logo.svg"
import "../../styles/navbar.css"

export default function Navbar(){

 const [open,setOpen]=useState(false)

 const navRef = useRef(null)

 const toggleMenu=()=>{
  setOpen(prev=>!prev)
 }

 const closeMenu=()=>{
  setOpen(false)
 }

 /* close menu when clicking outside */

 useEffect(()=>{

  function handleClickOutside(e){

   if(navRef.current && !navRef.current.contains(e.target)){
    setOpen(false)
   }

  }

  document.addEventListener("mousedown",handleClickOutside)

  return ()=>document.removeEventListener("mousedown",handleClickOutside)

 },[])

 /* close menu when resizing to desktop */

 useEffect(()=>{

  function handleResize(){

   if(window.innerWidth>768){
    setOpen(false)
   }

  }

  window.addEventListener("resize",handleResize)

  return ()=>window.removeEventListener("resize",handleResize)

 },[])

 return(

  <header
   ref={navRef}
   className={open ? "navbar nav-open" : "navbar"}
  >

   {/* LOGO */}

   <div className="logo">

    <img
     src={logo}
     alt="Portfolio Logo"
     className="logo-icon"
    />

    <span>Portfolio</span>

   </div>

   {/* MOBILE MENU BUTTON */}

   <button
    className="menu-toggle"
    onClick={toggleMenu}
    aria-label="Toggle navigation menu"
    aria-expanded={open}
   >

    <span></span>
    <span></span>
    <span></span>

   </button>

   {/* NAVIGATION */}

   <nav>

    <Link to="/portfolio" onClick={closeMenu}>
     Home
    </Link>

    <Link to="/portfolio/about" onClick={closeMenu}>
     About
    </Link>

    <Link to="/portfolio/projects" onClick={closeMenu}>
     Projects
    </Link>

    <Link to="/portfolio/blog" onClick={closeMenu}>
     Blog
    </Link>

    <Link to="/portfolio/contact" onClick={closeMenu}>
     Contact
    </Link>

   </nav>

  </header>

 )

}
`)

/* FOOTER */

write("src/components/Footer/Footer.tsx",`
import "../../styles/footer.css"

export default function Footer(){

 return(

  <footer className="footer">
   © 2026 Portfolio
  </footer>

 )

}
`)

console.log("Components created")