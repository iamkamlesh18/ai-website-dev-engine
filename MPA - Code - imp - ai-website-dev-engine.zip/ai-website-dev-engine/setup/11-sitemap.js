const fs = require("fs")
const path = require("path")

const project = process.argv[2]

/*
Base site URL
Update this later when deploying
*/

const SITE_URL = "https://example.com"

/*
All main pages
*/

const pages = [
"/portfolio",
"/portfolio/about",
"/portfolio/projects",
"/portfolio/blog",
"/portfolio/contact"
]

/*
Blog posts (must match posts.ts)
*/

const blogPosts = [
"/portfolio/blog/building-modern-websites",
"/portfolio/blog/digital-marketing-strategy"
]

/*
Combine all routes
*/

const routes = [...pages, ...blogPosts]

let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
`

routes.forEach(route => {

 xml += `
  <url>
   <loc>${SITE_URL}${route}</loc>
  </url>
 `

})

xml += `
</urlset>
`

/*
Ensure public folder exists
*/

const publicDir = path.join(project, "public")

if (!fs.existsSync(publicDir)) {
 fs.mkdirSync(publicDir)
}

/*
Write sitemap
*/

fs.writeFileSync(
 path.join(publicDir, "sitemap.xml"),
 xml.trim()
)

console.log("Sitemap generated")