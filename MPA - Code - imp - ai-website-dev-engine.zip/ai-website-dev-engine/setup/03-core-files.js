const fs = require("fs");
const { writeIfMissing, ensureDir } = require("./lib/context");
const { log } = require("./lib/logger");

const project = process.argv[2];
process.chdir(project);

/* replace vite favicon and update index.html */

if (fs.existsSync("public/vite.svg")) {
  fs.unlinkSync("public/vite.svg");
}

const indexHtmlPath = "index.html";

if (fs.existsSync(indexHtmlPath)) {
  const html = `
<!doctype html>
<html lang="en">

<head>

<meta charset="UTF-8" />

<link rel="icon" type="image/svg+xml" href="/logo.svg" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>Portfolio | Freelance Developer & Digital Services</title>

<meta name="description" content="Freelance portfolio offering website development, graphic design, branding and digital marketing services." />

<meta name="keywords" content="freelance developer, website development, graphic design, digital marketing, portfolio" />

<meta name="author" content="Portfolio" />

<!-- Open Graph -->

<meta property="og:title" content="Portfolio | Freelance Developer & Digital Services" />
<meta property="og:description" content="Modern freelance services including website development, branding, design and marketing." />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://example.com/portfolio" />
<meta property="og:image" content="/logo.svg" />

<!-- Twitter -->

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Portfolio | Freelance Developer" />
<meta name="twitter:description" content="Freelance portfolio offering development, design and marketing services." />
<meta name="twitter:image" content="/logo.svg" />

</head>

<body>

<div id="root"></div>

<script type="module" src="/src/main.tsx"></script>

</body>

</html>
`;

  fs.writeFileSync(indexHtmlPath, html.trim());
}

/* ensure folders */

ensureDir("src/pages");
ensureDir("src/layouts");
ensureDir("src/styles");

/* remove default css */

if (fs.existsSync("src/index.css")) fs.unlinkSync("src/index.css");
if (fs.existsSync("src/App.css")) fs.unlinkSync("src/App.css");

/* remove css import */

const mainFile = "src/main.tsx";

if (fs.existsSync(mainFile)) {
  let content = fs.readFileSync(mainFile, "utf8");

  content = content.replace(`import './index.css'`, "");
  content = content.replace(`import "./index.css"`, "");

  fs.writeFileSync(mainFile, content);
}

/* pages content */
writeIfMissing(
  "src/pages/Home.tsx",
  `
import {Link} from "react-router-dom"

import "../styles/hero.css"
import "../styles/features.css"
import "../styles/brands.css"
import "../styles/testimonials.css"
import "../styles/cta.css"

export default function Home(){

 return(

  <>

   {/* HERO */}

   <section className="hero">

    <h1 className="hero-title">Freelance Digital Studio</h1>

    <p>
     Building modern websites, strong brand identities
     and growth-driven digital marketing strategies
     for businesses and startups.
    </p>

    <Link to="/portfolio/contact" className="cta-btn">
     Start a Project
    </Link>

   </section>


   {/* TRUSTED BRANDS */}

   <section className="brands">

    <h2>Trusted By Growing Brands</h2>

    <div className="brand-list">

     <span>Healthcare Clinic</span>
     <span>E-commerce Store</span>
     <span>Real Estate Consultant</span>
     <span>Personal Brand</span>
     <span>Local Startup</span>

    </div>

   </section>


   {/* WHAT I BRING */}

   <section className="section">

    <h2>What I Bring To The Table</h2>

    <div className="features">

     <div className="card">
      <h3>Strategic Clarity</h3>
      <p>
       Clear positioning, target audience definition
       and measurable performance goals.
      </p>
     </div>

     <div className="card">
      <h3>Creative Communication</h3>
      <p>
       Content, branding and messaging that build
       authority and convert attention into trust.
      </p>
     </div>

     <div className="card">
      <h3>Performance Execution</h3>
      <p>
       Paid ads, SEO, automation systems
       and optimized web platforms designed to scale.
      </p>
     </div>

    </div>

   </section>


   {/* HOW I HELP BRANDS GROW */}

   <section className="section">

    <h2>How I Help Brands Grow</h2>

    <div className="features">

     <div className="card">
      <h3>Lead Generation Systems</h3>
      <p>
       Landing pages, funnels, ad campaigns
       and automation workflows converting visitors into clients.
      </p>
     </div>

     <div className="card">
      <h3>Authority Building</h3>
      <p>
       SEO, content strategy and brand positioning
       to dominate your niche.
      </p>
     </div>

     <div className="card">
      <h3>Conversion Optimization</h3>
      <p>
       Data-backed improvements increasing ROI
       without increasing ad spend.
      </p>
     </div>

    </div>

   </section>


   {/* GROWTH PROCESS */}

   <section className="section">

    <h2>My 3-Step Growth Process</h2>

    <div className="features">

     <div className="card">
      <h3>1. Strategy</h3>
      <p>
       Deep research, competitor analysis
       and audience psychology.
      </p>
     </div>

     <div className="card">
      <h3>2. Build</h3>
      <p>
       Content systems, marketing campaigns
       and optimized platforms.
      </p>
     </div>

     <div className="card">
      <h3>3. Scale</h3>
      <p>
       Data-driven optimization,
       automation and continuous improvement.
      </p>
     </div>

    </div>

   </section>


   {/* TESTIMONIALS */}

   <section className="testimonials">

    <h2>Client Testimonials</h2>

    <div className="testimonials-grid">

     <div className="testimonial">
      <p>"The website transformed our online presence."</p>
      <span>— Startup Founder</span>
     </div>

     <div className="testimonial">
      <p>"Great branding and marketing systems."</p>
      <span>— Marketing Manager</span>
     </div>

     <div className="testimonial">
      <p>"Professional execution and excellent communication."</p>
      <span>— Business Owner</span>
     </div>

    </div>

   </section>


   {/* CTA */}

     <section className="cta">

        <h2>Ready to Build Something Great?</h2>

        <p>
            Let's create modern websites, strong brand identities,
            and digital marketing systems that help your business grow.
        </p>

        <button>Contact Now</button>
    </section>

  </>

 )

}
`,
);

writeIfMissing(
  "src/pages/About.tsx",
  `
export default function About(){

 return(

  <div className="container">

   <h1>About</h1>

   <p>
   This portfolio represents a freelancing digital agency focused on building
   modern digital systems for brands and businesses.
   </p>

   <p>
   Services include website development, branding, graphic design,
   performance marketing, automation systems and technical architecture.
   </p>

  </div>

 )

}
`,
);

writeIfMissing(
  "src/pages/Projects.tsx",
  `
export default function Projects(){

 return(

  <div className="container">

   <h1>Projects</h1>

   <p>
   Selected work across websites, branding systems,
   marketing campaigns and product launches.
   </p>

   <ul>
    <li>Corporate website development</li>
    <li>Brand identity design</li>
    <li>Marketing campaign landing pages</li>
    <li>E-commerce systems</li>
   </ul>

  </div>

 )

}
`,
);

writeIfMissing(
  "src/pages/Blog.tsx",
  `
export default function Blog(){

 return(

  <div className="container">

   <h1>Blog</h1>

   <p>
   Articles covering technology, marketing strategy,
   design systems and building scalable digital products.
   </p>

  </div>

 )

}
`,
);

writeIfMissing(
  "src/pages/Contact.tsx",
  `
export default function Contact(){

 return(

  <div className="container">

   <h1>Contact</h1>

   <p>
   Interested in working together?
   Reach out for freelance projects, collaborations or consulting.
   </p>

   <p>Email: contact@portfolio.com</p>

  </div>

 )

}
`,
);

/* layout */

writeIfMissing(
  "src/layouts/MainLayout.tsx",
  `
import Navbar from "../components/Navbar/Navbar"
import Footer from "../components/Footer/Footer"
import {Outlet} from "react-router-dom"

export default function MainLayout(){

 return(

  <div className="layout">

   <Navbar/>

   <main className="content">
    <Outlet/>
   </main>

   <Footer/>

  </div>

 )

}
`,
);

/* app router */

fs.writeFileSync(
  "src/App.tsx",
  `
import "./styles/global.css"

import {BrowserRouter,Routes,Route} from "react-router-dom"

import MainLayout from "./layouts/MainLayout"

import Home from "./pages/Home"
import About from "./pages/About"
import Projects from "./pages/Projects"
import Blog from "./pages/Blog"
import BlogPost from "./pages/BlogPost"
import Contact from "./pages/Contact"

function App(){

 return(

  <BrowserRouter>

   <Routes>

    <Route element={<MainLayout/>}>

     <Route path="/portfolio" element={<Home/>}/>
     <Route path="/portfolio/about" element={<About/>}/>
     <Route path="/portfolio/projects" element={<Projects/>}/>
     <Route path="/portfolio/blog" element={<Blog/>}/>
     <Route path="/portfolio/blog/:slug" element={<BlogPost/>}/>
     <Route path="/portfolio/contact" element={<Contact/>}/>

     {/* fallback route */}
     <Route path="*" element={<Home/>}/>

    </Route>

   </Routes>

  </BrowserRouter>

 )

}

export default App
`.trim(),
);

log("CORE", "Multi page architecture created");
