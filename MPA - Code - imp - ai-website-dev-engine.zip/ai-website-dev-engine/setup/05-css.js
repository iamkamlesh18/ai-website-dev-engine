const fs=require("fs")
const project=process.argv[2]

process.chdir(project)

function write(file,content){
 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }
}

/* ============================================================
GLOBAL DESIGN SYSTEM
============================================================ */

write("src/styles/global.css",`

:root{

 --bg1:#0f172a;
 --bg2:#1e293b;

 --text:#f1f5f9;
 --muted:#94a3b8;

 --primary:#6366f1;
 --secondary:#22c55e;
 --accent:#f59e0b;

 --card:#1e293b;
 --border:#334155;

 --radius:10px;

 --container:1200px;

}

/* RESET */

*{
 margin:0;
 padding:0;
 box-sizing:border-box;
}

html{
 scroll-behavior:smooth;
}

html,body{
 overflow-x:hidden;
}

body{

 font-family:
 system-ui,
 -apple-system,
 Segoe UI,
 Roboto,
 Ubuntu;

 background:
 radial-gradient(circle at top,#1e293b,#020617);

 color:var(--text);

 line-height:1.6;

 min-height:100vh;

}

/* LAYOUT */

.layout{
 min-height:100vh;
 display:flex;
 flex-direction:column;
}

.content{
 flex:1;
 padding-bottom:80px;
}

/* CONTAINER */

.container{
 max-width:var(--container);
 margin:auto;
 padding:0 20px;
}

/* SECTIONS */

section{
 width:100%;
 padding:120px 20px;
 animation:fadeUp .7s ease both;
}

.section{
 max-width:var(--container);
 margin:auto;
 padding:100px 20px;
}

/* TYPOGRAPHY */

h1{
 font-size:52px;
 margin-bottom:20px;
}

h2{
 font-size:36px;
 margin-bottom:20px;
 text-align:center;
}

h3{
 font-size:20px;
 margin-bottom:10px;
}

p{
 color:var(--muted);
}

/* BUTTON SYSTEM */

button,
.cta-btn{

 padding:12px 26px;

 border:none;

 border-radius:var(--radius);

 background:
 linear-gradient(135deg,var(--primary),var(--secondary));

 color:white;

 font-weight:600;

 cursor:pointer;

 transition:all .25s ease;

 text-decoration:none;

 display:inline-block;

}

button:hover,
.cta-btn:hover{

 transform:translateY(-2px);

 box-shadow:0 10px 25px rgba(0,0,0,.4);

}

/* UTILITIES */

.grid{
 display:grid;
 gap:30px;
}

.flex{
 display:flex;
 align-items:center;
}

.center{
 text-align:center;
}

/* ANIMATION */

@keyframes fadeUp{

 from{
  opacity:0;
  transform:translateY(30px);
 }

 to{
  opacity:1;
  transform:translateY(0);
 }

}

/* RESPONSIVE */

@media (max-width:1200px){

 h1{font-size:44px}

}

@media (max-width:992px){

 h1{font-size:38px}
 h2{font-size:30px}

 section{
  padding:100px 20px;
 }

}

@media (max-width:768px){

 h1{font-size:32px}
 h2{font-size:26px}

 section{
  padding:80px 20px;
 }

}

@media (max-width:480px){

 h1{font-size:28px}

}

`)

/* ============================================================
NAVBAR (FIXED HAMBURGER + MOBILE MENU)
============================================================ */

write("src/styles/navbar.css",`

.navbar{

 width:100%;

 display:flex;
 justify-content:space-between;
 align-items:center;

 padding:20px 40px;

 background:rgba(15,23,42,.7);

 backdrop-filter:blur(12px);

 border-bottom:1px solid var(--border);

 position:sticky;

 top:0;

 z-index:100;

 position:relative;

}

/* LOGO */

.logo{

 display:flex;
 align-items:center;
 gap:10px;

 font-size:20px;
 font-weight:700;

 color:var(--primary);

}

.logo-icon{

 width:36px;
 height:36px;

 animation:logoFloat 4s ease-in-out infinite;

}

.logo:hover .logo-icon{
 transform:scale(1.15) rotate(8deg);
}

/* NAV LINKS */

.navbar nav{

 display:flex;
 gap:28px;

 align-items:center;

}

.navbar a{

 text-decoration:none;
 color:var(--text);
 font-weight:500;
 position:relative;

}

.navbar a::after{

 content:"";
 position:absolute;
 left:0;
 bottom:-6px;

 width:0;
 height:2px;

 background:var(--secondary);

 transition:.25s;

}

.navbar a:hover::after{
 width:100%;
}

/* HAMBURGER */

.menu-toggle{

 display:none;
 flex-direction:column;
 gap:5px;
 cursor:pointer;
 background:none;
 border:none;

}

.menu-toggle span{

 width:26px;
 height:3px;

 background:var(--text);

 border-radius:2px;

 transition:.3s;

}

/* MOBILE */

@media (max-width:768px){

 .navbar{
  padding:16px 20px;
 }

 .menu-toggle{
  display:flex;
 }

 .navbar nav{

  position:absolute;
  top:100%;
  left:0;

  width:100%;

  background:var(--bg1);

  flex-direction:column;

  align-items:center;

  gap:20px;

  padding:30px 20px;

  border-bottom:1px solid var(--border);

  transform:translateY(-150%);
  opacity:0;

  pointer-events:none;

  transition:transform .35s ease,opacity .35s ease;

 }

 .navbar.nav-open nav{

  transform:translateY(0);

  opacity:1;

  pointer-events:auto;

 }

}

/* HAMBURGER → X */

.nav-open .menu-toggle span:nth-child(1){
 transform:rotate(45deg) translateY(8px);
}

.nav-open .menu-toggle span:nth-child(2){
 opacity:0;
}

.nav-open .menu-toggle span:nth-child(3){
 transform:rotate(-45deg) translateY(-8px);
}

/* LOGO FLOAT */

@keyframes logoFloat{

 0%{transform:translateY(0px)}
 50%{transform:translateY(-4px)}
 100%{transform:translateY(0px)}

}

`)

/* ============================================================
HERO
============================================================ */

write("src/styles/hero.css",`

.hero{

 max-width:900px;
 margin:auto;

 text-align:center;

 padding:160px 20px;

}

.hero h1{

 font-size:56px;

 background:
 linear-gradient(135deg,#6366f1,#22c55e);

 -webkit-background-clip:text;
 -webkit-text-fill-color:transparent;

}

.hero p{

 font-size:20px;
 margin-bottom:30px;

}

.hero-title{
 animation:heroBounce 2.5s ease infinite;
}

@keyframes heroBounce{

 0%{transform:translateY(0)}
 50%{transform:translateY(-10px)}
 100%{transform:translateY(0)}

}

@media (max-width:768px){

 .hero{
  padding:120px 20px;
 }

 .hero h1{
  font-size:38px;
 }

 .hero p{
  font-size:18px;
 }

}

`)

/* ============================================================
FEATURES / CARDS
============================================================ */

write("src/styles/features.css",`

.section{
 padding:100px 20px;
}

.section h2{
 text-align:center;
 margin-bottom:40px;
 font-size:28px;
}

.features{

 max-width:1100px;
 margin:auto;

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(260px,1fr));

 gap:30px;

}

.card{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:30px;

 text-align:center;

 transition:.3s;

}

.card:hover{

 transform:translateY(-6px);

 box-shadow:0 15px 35px rgba(0,0,0,.4);

}

.card h3{
 margin-bottom:12px;
}

@media (max-width:768px){

 .features{
  grid-template-columns:1fr;
 }

}

`)

/* ============================================================
BRANDS
============================================================ */

write("src/styles/brands.css",`

/* ============================================================
TRUSTED BY BRANDS SECTION
============================================================ */

.brands{

 padding:110px 20px;

 text-align:center;

 position:relative;

 border-top:1px solid var(--border);
 border-bottom:1px solid var(--border);

 background:
 linear-gradient(
 180deg,
 rgba(15,23,42,.15),
 rgba(15,23,42,.05)
 );

}

/* SECTION TITLE */

.brands h2{

 font-size:13px;

 letter-spacing:4px;

 text-transform:uppercase;

 color:var(--muted);

 margin-bottom:50px;

 font-weight:600;

}

/* BRAND ROW */

.brand-list{

 display:flex;

 justify-content:center;

 align-items:center;

 gap:50px;

 max-width:1100px;

 margin:auto;

 flex-wrap:nowrap;

}

/* BRAND ITEMS */

.brand-list span{

 font-size:20px;

 font-weight:600;

 letter-spacing:.6px;

 color:#cbd5f5;

 opacity:.45;

 transition:all .25s ease;

 cursor:default;

}

/* POP-UP EFFECT */

.brand-list span:hover{

 opacity:1;

 color:white;

 transform:translateY(-5px) scale(1.05);

 text-shadow:
 0 6px 18px rgba(0,0,0,.35);

}

/* MOBILE */

@media (max-width:768px){

 .brand-list{

  flex-wrap:wrap;

  gap:20px;

 }

 .brand-list span{

  font-size:16px;

 }

}

`)

/* ============================================================
TESTIMONIALS
============================================================ */

write("src/styles/testimonials.css",`

.testimonials{

 max-width:1100px;
 margin:auto;

}

.testimonials-grid{

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(260px,1fr));

 gap:30px;

 margin-top:40px;

}

.testimonial{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:25px;

}

.testimonial span{

 display:block;
 margin-top:12px;

 color:var(--secondary);

}

`)

/* ============================================================
CTA (READY TO BUILD FIXED)
============================================================ */

write("src/styles/cta.css",`

.cta{

 text-align:center;

 max-width:950px;

 margin:120px auto;

 padding:80px 40px;

 border-radius:var(--radius);

 background:
 linear-gradient(
 135deg,
 rgba(99,102,241,.18),
 rgba(34,197,94,.18)
 );

 border:1px solid var(--border);

 box-shadow:
 0 30px 70px rgba(0,0,0,.35);

 position:relative;

 overflow:hidden;

}

/* subtle glow effect */

.cta::before{

 content:"";

 position:absolute;

 inset:-1px;

 background:
 radial-gradient(
 600px circle at 50% 0%,
 rgba(99,102,241,.35),
 transparent
 );

 opacity:.5;

 pointer-events:none;

}

/* TITLE */

.cta h2{

 font-size:40px;

 font-weight:700;

 letter-spacing:.4px;

 margin-bottom:18px;

}

/* DESCRIPTION */

.cta p{

 max-width:640px;

 margin:auto;

 margin-bottom:36px;

 font-size:18px;

 color:var(--muted);

}

/* BUTTON */

.cta button{

 font-size:16px;

 padding:14px 34px;

}

/* MOBILE */

@media (max-width:768px){

 .cta{

  width:calc(100% - 40px);

  margin:80px auto;

  padding:50px 22px;

 }

 .cta h2{
  font-size:28px;
 }

 .cta p{
  font-size:16px;
 }

}

`)

/* ============================================================
FOOTER
============================================================ */

write("src/styles/footer.css",`

.footer{

 width:100%;

 padding:20px;

 text-align:center;

 border-top:1px solid var(--border);

 background:var(--bg1);

 color:var(--muted);

 margin-top:auto;

}

`)

console.log("Advanced CSS system created")