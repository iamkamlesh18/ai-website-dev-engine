module.exports = {
  defaultProjectName: "portfolio",
  dependencies: [
    "react-router-dom",
    "axios"
  ],
  structure: [
    "src/components/Navbar",
    "src/components/Footer",
    "src/pages",
    "src/layouts",
    "src/styles",
    "src/hooks",
    "src/services",
    "src/utils",
    "src/types"
  ]
}