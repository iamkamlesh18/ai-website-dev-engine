const fs=require("fs")
const path=require("path")

const project=process.argv[2]
process.chdir(project)

function write(file,content){

 const dir=path.dirname(file)

 if(!fs.existsSync(dir)){
  fs.mkdirSync(dir,{recursive:true})
 }

 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }

}

write("src/components/SEO/SEO.tsx",`

import {useEffect} from "react"

interface Props{
 title:string
 description:string
}

export default function SEO({title,description}:Props){

 useEffect(()=>{

  document.title=title

  const meta=document.querySelector("meta[name='description']")

  if(meta){
   meta.setAttribute("content",description)
  }

 },[title,description])

 return null

}

`)

console.log("SEO system generated")