const fs=require("fs")
const path=require("path")

const project=process.argv[2]
process.chdir(project)

function write(file,content){

 const dir=path.dirname(file)

 if(!fs.existsSync(dir)){
  fs.mkdirSync(dir,{recursive:true})
 }

 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }

}

/* blog data */

write("src/data/posts.ts",`

export const posts=[

{
 slug:"building-modern-websites",
 title:"Building Modern Websites",
 excerpt:"How modern websites are designed for performance and growth",
 content:"Website development today focuses on speed, SEO and scalability."
},

{
 slug:"digital-marketing-strategy",
 title:"Digital Marketing Strategy",
 excerpt:"How businesses grow using digital marketing",
 content:"SEO, content strategy and performance marketing together build growth."
}

]

`)

/* blog page */

write("src/pages/BlogPost.tsx",`

import {useParams} from "react-router-dom"
import {posts} from "../data/posts"

export default function BlogPost(){

 const {slug}=useParams()

 const post=posts.find(p=>p.slug===slug)

 if(!post){
  return <div>Post not found</div>
 }

 return(

  <div className="container">

   <h1>{post.title}</h1>

   <p>{post.content}</p>

  </div>

 )

}

`)

console.log("Blog system generated")