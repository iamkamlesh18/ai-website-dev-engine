const fs = require("fs")
const path = require("path")
const {writeIfMissing, ensureDir} = require("./lib/context")
const {log} = require("./lib/logger")

const project = process.argv[2]

process.chdir(project)

/*
------------------------------------------
Replace Vite favicon with generated logo
------------------------------------------
*/

if(fs.existsSync("public/vite.svg")){
 fs.unlinkSync("public/vite.svg")
}

const indexHtmlPath = "index.html"

if(fs.existsSync(indexHtmlPath)){

 let html = fs.readFileSync(indexHtmlPath,"utf8")

 html = html.replace("/vite.svg","/logo.svg")

 fs.writeFileSync(indexHtmlPath,html)

}

/*
------------------------------------------
Ensure required folders exist
------------------------------------------
*/

ensureDir("src/pages")
ensureDir("src/components")
ensureDir("src/styles")

/*
------------------------------------------
Remove default Vite CSS to avoid conflicts
------------------------------------------
*/

if(fs.existsSync("src/index.css")){
 fs.unlinkSync("src/index.css")
}

if(fs.existsSync("src/App.css")){
 fs.unlinkSync("src/App.css")
}

/*
------------------------------------------
Remove index.css import from main.tsx
------------------------------------------
*/

const mainFile = "src/main.tsx"

if(fs.existsSync(mainFile)){

 let content = fs.readFileSync(mainFile,"utf8")

 content = content.replace(`import './index.css'`,"")
 content = content.replace(`import "./index.css"`,"")

 fs.writeFileSync(mainFile,content)

}

/*
------------------------------------------
Create Home Landing Page
Full SaaS layout
------------------------------------------
*/

writeIfMissing("src/pages/Home.tsx",`
import Navbar from "../components/Navbar/Navbar"
import Hero from "../components/Hero/Hero"
import Features from "../components/Features/Features"
import Testimonials from "../components/Testimonials/Testimonials"
import Pricing from "../components/Pricing/Pricing"
import Blog from "../components/Blog/Blog"
import About from "../components/About/About"
import Projects from "../components/Projects/Projects"
import Contact from "../components/Contact/Contact"
import CTA from "../components/CTA/CTA"
import Footer from "../components/Footer/Footer"

export default function Home(){
 return(
  <div>

   <Navbar/>

   <Hero/>

   <Features/>

   <Testimonials/>

   <Pricing/>

   <Blog/>

   <About/>

   <Projects/>

   <Contact/>

   <CTA/>

   <Footer/>

  </div>
 )
}
`)

/*
------------------------------------------
Update App.tsx to load Home + Global CSS
------------------------------------------
*/

fs.writeFileSync("src/App.tsx",`
import "./styles/global.css"
import Home from "./pages/Home"

function App(){
 return <Home/>
}

export default App
`.trim())

/*
------------------------------------------
Log completion
------------------------------------------
*/

log("CORE","Landing page core created")