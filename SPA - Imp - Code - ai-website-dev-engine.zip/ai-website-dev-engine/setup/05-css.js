const fs=require("fs")
const project=process.argv[2]

process.chdir(project)

function write(file,content){
 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }
}

/* GLOBAL DESIGN SYSTEM */

write("src/styles/global.css",`

:root{

 --bg1:#0f172a;
 --bg2:#1e293b;

 --text:#f1f5f9;
 --muted:#94a3b8;

 --primary:#6366f1;
 --secondary:#22c55e;
 --accent:#f59e0b;

 --card:#1e293b;
 --border:#334155;

 --radius:10px;

}

*{
 margin:0;
 padding:0;
 box-sizing:border-box;
}

html{
 scroll-behavior:smooth;
}

body{

 font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu;

 background:
 radial-gradient(circle at top,#1e293b,#020617);

 color:var(--text);

 line-height:1.6;

 min-height:100vh;

}

/* layout */

section{
 width:100%;
 padding:120px 20px;
 animation:fadeUp .7s ease both;
}

.container{
 max-width:1200px;
 margin:auto;
}

/* typography */

h1{
 font-size:52px;
 margin-bottom:20px;
}

h2{
 font-size:36px;
 margin-bottom:20px;
 text-align:center;
}

p{
 color:var(--muted);
}

/* button */

button{

 padding:12px 26px;

 border:none;

 border-radius:var(--radius);

 background:
 linear-gradient(135deg,var(--primary),var(--secondary));

 color:white;

 font-weight:600;

 cursor:pointer;

 transition:all .25s ease;

}

button:hover{

 transform:translateY(-2px);
 box-shadow:0 10px 25px rgba(0,0,0,.4);

}

/* animation */

@keyframes fadeUp{

 from{
  opacity:0;
  transform:translateY(30px);
 }

 to{
  opacity:1;
  transform:translateY(0);
 }

}

`)

/* NAVBAR */

write("src/styles/navbar.css",`

.navbar{

 width:100%;

 display:flex;
 justify-content:space-between;
 align-items:center;

 padding:20px 40px;

 background:rgba(15,23,42,.7);

 backdrop-filter:blur(12px);

 border-bottom:1px solid var(--border);

 position:sticky;

 top:0;

 z-index:100;

}

.logo{

 display:flex;
 align-items:center;
 gap:10px;

 font-size:20px;
 font-weight:700;

 color:var(--primary);

}

.navbar nav{

 display:flex;
 gap:28px;

}

.navbar a{

 text-decoration:none;

 color:var(--text);

 font-weight:500;

 position:relative;

}

.navbar a::after{

 content:"";
 position:absolute;
 left:0;
 bottom:-6px;

 width:0;
 height:2px;

 background:var(--secondary);

 transition:.25s;

}

.navbar a:hover::after{
 width:100%;
}

`)

/* HERO */

write("src/styles/hero.css",`

.hero{

 max-width:900px;

 margin:auto;

 text-align:center;

 padding:160px 20px;

}

.hero h1{

 font-size:56px;

 background:
 linear-gradient(135deg,#6366f1,#22c55e);

 -webkit-background-clip:text;
 -webkit-text-fill-color:transparent;

}

.hero p{

 font-size:20px;

 margin-bottom:30px;

}

`)

/* FEATURES */

write("src/styles/features.css",`

.features{

 max-width:1100px;

 margin:auto;

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(250px,1fr));

 gap:30px;

}

.card{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:30px;

 text-align:center;

 transition:.3s;

}

.card:hover{

 transform:translateY(-6px);

 box-shadow:0 15px 35px rgba(0,0,0,.4);

}

.card h3{
 margin-bottom:10px;
}

`)

/* TESTIMONIALS */

write("src/styles/testimonials.css",`

.testimonials{

 max-width:1100px;

 margin:auto;

}

.testimonials-grid{

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(260px,1fr));

 gap:30px;

 margin-top:40px;

}

.testimonial{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:25px;

}

.testimonial span{

 display:block;

 margin-top:12px;

 color:var(--secondary);

}

`)

/* PRICING */

write("src/styles/pricing.css",`

.pricing{

 max-width:1100px;

 margin:auto;

}

.pricing-grid{

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(260px,1fr));

 gap:30px;

 margin-top:40px;

}

.plan{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:35px;

 text-align:center;

 transition:.3s;

}

.plan:hover{

 transform:scale(1.04);

 box-shadow:0 15px 40px rgba(0,0,0,.4);

}

.plan.popular{

 border:2px solid var(--primary);

}

.plan h3{

 margin-bottom:10px;

}

`)

/* BLOG */

write("src/styles/blog.css",`

.blog{

 max-width:1100px;

 margin:auto;

}

.blog-grid{

 display:grid;

 grid-template-columns:repeat(auto-fit,minmax(260px,1fr));

 gap:30px;

 margin-top:40px;

}

.post{

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:25px;

 transition:.25s;

}

.post:hover{

 transform:translateY(-5px);

}

`)

/* ABOUT */

write("src/styles/about.css",`

.about{

 max-width:800px;

 margin:auto;

 text-align:center;

}

`)

/* PROJECTS */

write("src/styles/projects.css",`

.projects{

 max-width:1100px;

 margin:auto;

 text-align:center;

}

.projects p{
 margin-top:10px;
}

`)

/* CONTACT */

write("src/styles/contact.css",`

.contact{

 max-width:700px;

 margin:auto;

 text-align:center;

 background:var(--card);

 border:1px solid var(--border);

 border-radius:var(--radius);

 padding:40px;

}

.contact p{
 margin-top:10px;
}

`)

/* CTA */

write("src/styles/cta.css",`

.cta{

 text-align:center;

 background:
 linear-gradient(135deg,#6366f1,#22c55e);

 padding:80px 40px;

 border-radius:var(--radius);

 max-width:900px;

 margin:80px auto;

 box-shadow:0 20px 40px rgba(0,0,0,.4);

}

.cta h2{
 margin-bottom:20px;
}

`)

/* FOOTER */

write("src/styles/footer.css",`

.footer{

 padding:40px;

 text-align:center;

 border-top:1px solid var(--border);

 margin-top:80px;

 color:var(--muted);

}

`)

console.log("Advanced CSS system created")