const fs=require("fs")
const path=require("path")

const project=process.argv[2]

process.chdir(project)

const projectName=project.charAt(0).toUpperCase()+project.slice(1)

function write(file,content){

 const dir=path.dirname(file)

 if(!fs.existsSync(dir)){
  fs.mkdirSync(dir,{recursive:true})
 }

 if(!fs.existsSync(file)){
  fs.writeFileSync(file,content.trim())
 }

}

/* NAVBAR */

write("src/components/Navbar/Navbar.tsx",`
import "../../styles/navbar.css"

export default function Navbar(){
 return(
  <header className="navbar">
   <div className="logo">${projectName}</div>
   <nav>
    <a href="#features">Features</a>
    <a href="#about">About</a>
    <a href="#projects">Projects</a>
    <a href="#contact">Contact</a>
   </nav>
  </header>
 )
}
`)

/* HERO */

write("src/components/Hero/Hero.tsx",`
import "../../styles/hero.css"

export default function Hero(){
 return(
  <section className="hero">
   <h1>Welcome to ${projectName}</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore.</p>
   <button>Get Started</button>
  </section>
 )
}
`)

/* FEATURES */

write("src/components/Features/Features.tsx",`
import "../../styles/features.css"

export default function Features(){
 return(
  <section id="features" className="features">
   <div className="card"><h3>Fast</h3></div>
   <div className="card"><h3>Modern</h3></div>
   <div className="card"><h3>AI Ready</h3></div>
  </section>
 )
}
`)

/* ABOUT */

write("src/components/About/About.tsx",`
import "../../styles/about.css"

export default function About(){
 return(
  <section id="about" className="about">
   <h2>About</h2>
   <p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
  </section>
 )
}
`)

/* PROJECTS */

write("src/components/Projects/Projects.tsx",`
import "../../styles/projects.css"

export default function Projects(){
 return(
  <section id="projects" className="projects">
   <h2>Projects</h2>
   <p>Lorem ipsum dolor sit amet consectetur adipiscing elit.</p>
  </section>
 )
}
`)

/* CONTACT */

write("src/components/Contact/Contact.tsx",`
import "../../styles/contact.css"

export default function Contact(){
 return(
  <section id="contact" className="contact">
   <h2>Contact</h2>
   <p>Lorem ipsum dolor sit amet consectetur adipiscing elit.</p>
   <p>Email: contact@${project}.com</p>
   <p>Phone: +91 90000 00000</p>
  </section>
 )
}
`)

/* CTA */

write("src/components/CTA/CTA.tsx",`
import "../../styles/cta.css"

export default function CTA(){
 return(
  <section className="cta">
   <h2>Start building today</h2>
   <button>Get Started</button>
  </section>
 )
}
`)

/* FOOTER */

write("src/components/Footer/Footer.tsx",`
import "../../styles/footer.css"

export default function Footer(){
 return(
  <footer className="footer">
   <p>© 2026 ${projectName}</p>
  </footer>
 )
}
`)

console.log("Components created")